/* 
* Nombre y Apellido: Gari Arellano Zubía y Alain Cascán Zalewska
* NIP: 848905 y 849183
* Asignatura: Tecnología de la Programación
* Fecha: 20/03/2023
* Practica 3: practica3.h
*/
#pragma once
#include "item.h"
#include "almacen.h"
#include "camion.h"
#include "carga.h"
#include "contenedor.h"
#include "producto.h"
#include "servivo.h"