/* 
* Nombre y Apellido: Gari Arellano Zubía y Alain Cascán Zalewska
* NIP: 848905 y 849183
* Asignatura: Tecnología de la Programación
* Fecha: 10/03/2023
* Practica 3: practica3.h
*/
#pragma once
#include <iostream>
#include <vector>
#include <iomanip>
using namespace std;

// Clase padre que representa los distintos tipos de item que tenemos.
class Item { 
protected:
    // Atributos compartidos por todos los item.
    string _name;
    double _volume;
    double _weight;
    
public:
    Item(string name, double volume, double weight): _name(name), _volume(volume), _weight(weight){} 
    virtual string nombre() const{
        return _name;
    }
    virtual double volumen() const { 
        return _volume;
    }
    virtual double peso() const {
        return _weight;
    }
    virtual string tipo() const {
        return "";
    }
    virtual void pintar(ostream& os,const int nivel) const {
        os << setw(nivel) << " " <<_name << " [" << _volume << "m3] [" << peso() << "kg]" <<endl;
    }
    friend ostream& operator<<(ostream& os, const Item& item) {
        item.pintar(os,0);
        return os;
    }; 
};

// Clase intermedia que representa lo que es una carga estandar (que puede ser un producto estandar o un contenedor).
class Carga : public Item { 
public:
    Carga(string name, double volume, double weight): Item(name, volume, weight){}
    string tipo() const override { 
        return "Carga Estandar";
    }  
};

// Clase intermedia que representa los dos tipos de item para almacenar (contendor y camión)
// Clase de tipo generico ya que en un elemento de tipo almacen podemos guardar distintos tipos de datos.
template <typename T>
class Almacen { 
protected:  
    // Atributos compartidos por todos los almacenes.
    double _freeCapacity;
    vector<T*> _content;
public:
    Almacen(double capacity):_freeCapacity(capacity), _content(){} 
    
    bool guardar( T* elemento) {
        if(elemento->volumen() <= _freeCapacity) {
            _freeCapacity -= elemento->volumen();
            _content.push_back(elemento);
            return true;
        }
        return false;
    }
};

// Clase que representa un contendor, al ser un elemento para almacenar y una carga, hereda de las clases Almacen y Carga (Carga hereda de Item)
// Clase de tipo generico ya que el contenedor puede guardar mas de un tipo de dato, utilizamos el parametro T para instanciar la clase 
// Almacen con el mismo tipo de dato que nos pasan a Contenedor, ya que un Contenedor puede guardar otro.
template <typename T>
class Contenedor : public Almacen<T>, public Carga  { 
public:
    Contenedor(double volume): Almacen<T>(volume), Carga("Contenedor", volume, 0) {}
    //Método pintar redefinido para imprimir por pantalla el contenido del elemento de almacen.
    void pintar(ostream& os, const int nivel) const override {
        os << setw(nivel) << " " << _name << " [" << _volume << "m3] [" << peso() << "kg] de " << this->_content.front()->tipo() << endl;
        for (auto i : this->_content) {
            i->pintar(os, nivel+2);
        }
    }
    
    //Método peso redefinido para calcular el peso del camión en base al peso de todo lo que tiene almacenado
    double peso() const override {
        double weight = 0;
        for (auto i : this->_content) {
            weight += i->peso();
        }
        return weight;
    }
  
};

// Clase hija de Almacen de tipo carga(debido a que en un camión se pueden almacenar contenedores y productos estandar) y de Item.
// Especificamos que el tipo de Almacen es un tipo de dato carga, ya que un camión no puede contener a otro camión, solo productos o contenedores.
class Camion : public Almacen<Carga>, public Item{ 
public:
    Camion(double capacity):Almacen(capacity),Item("Camion",capacity,0){} 
    
    // Método peso redefinido para calcular el peso del camión en base al peso de todo lo que tiene almacenado
    double peso() const override {
        double weight = 0;
        for (auto i : this->_content) {
            weight += i->peso();
        }
        return weight;
    }

    // Método pintar redefinido para imprimir por pantalla el contenido del elemento de almacen.
    void pintar(ostream& os,const int nivel) const override {
        if (nivel == 0) {
            os << _name << " [" << _volume << "m3] [" << peso() << "kg]" << endl;
        } else {
            os << setw(nivel) << " "<< _name << " [" << _volume << "m3] [" << peso() << "kg]" << endl;
        }
        for (auto i : this->_content) {
            i->pintar(os,nivel+2);
        }
    }
};

// Clase hija de Carga la cual hereda de otra clase padre Item y representa un producto estandar.
// Esta clase no tiene ni atributos ni métodos propios ya que los hereda de carga y este a su vez de item.
class Producto : public Carga { 
public:
    Producto(string name, double volume, double weight): Carga(name, volume, weight){}
};

// Las clases Tóxico y SerVivo no pueden ser hijas de Carga ya que tenemos que asegurar que no se puedan guardar productos tóxicos y 
// seres vivos

// Clase que representa un producto toxico, que hereda de la clase Item.
class Toxico : public Item { 
public:
    Toxico(string name, double volume, double weight): Item(name, volume, weight){}
    //Método pintar redefinido para imprimir por pantalla el contenido del elemento de almacen.
    string tipo() const override { 
        return " Productos Toxicos";
    }
};

// Clase hija de item la cual representa a un ser vivo el cual puede ser cargado en un contenedor
class SerVivo : public Item { 
public:
    SerVivo(string name, double volume, double weight): Item(name, volume, weight){}
    
    // Método tipo redefinido de la clase Item
    string tipo() const override { 
        return "Seres Vivos";
    }
    
};
